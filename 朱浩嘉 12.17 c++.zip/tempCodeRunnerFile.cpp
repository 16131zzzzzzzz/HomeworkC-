#include<iostream>
#include<array>
using namespace std;

int main(){